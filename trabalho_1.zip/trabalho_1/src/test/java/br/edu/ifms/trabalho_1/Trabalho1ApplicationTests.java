package br.edu.ifms.trabalho_1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Trabalho1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
